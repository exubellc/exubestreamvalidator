# Exube Stream Validator

A lightweight Python utility to detect fake livestreams labeled as "LIVE" but replaying pre-recorded content.

## Purpose
This tool identifies deceptive streaming practices by checking for:
- Missing live chat
- Previously uploaded content
- Non-live source type
- Time discrepancy

## Use Case
For creators, watchdogs, or viewers who want truth in digital broadcasting.

## Created by
Malachi Hargrave, Exube LLC™
